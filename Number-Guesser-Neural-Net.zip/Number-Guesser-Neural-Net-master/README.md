# Number Guesser Neural Network

This program is my version of solving the MNIST Digit data set. It allows the user to draw a number on the screen and have the program take a guess of which digit it is. This uses a basic neural network model.


# Requirements
- Python 3.6 or below
- Pygame
- TKinter
- Tensroflow
- Keras
- Numpy
- Matplotlib

